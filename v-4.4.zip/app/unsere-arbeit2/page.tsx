import Comp from "../components/usere-arbeit2/Comp";
async function page() {
  return <Comp />;
}

export default page;
