import JederBedarf from "@/app/components/JederBedarf";

function page() {
  return <JederBedarf />;
}

export default page;
