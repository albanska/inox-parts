import LoadingState from "./components/home/LoadingState";

export default function Home() {
  return <LoadingState />;
}
