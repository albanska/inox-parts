import UnsereArbeit from "@/app/components/UnsereArbeit";

function page() {
  return <UnsereArbeit />;
}

export default page;
