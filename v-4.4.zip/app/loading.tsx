import React from 'react'
import Loader from './components/loader/Loader'

function loading() {
  return (
    <Loader />
  )
}

export default loading
