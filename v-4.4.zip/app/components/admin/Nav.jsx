"use client";

import { logout } from "@/lib/logout";

function Nav() {
  return (
    <div className="h-screen w-[200px]">
      <div className="h-full w-full relative">
        <form
          action={logout}
          className="absolute bottom-0 w-full flex h-10  justify-center items-center text-xl font-semibold tracking-wide text-[#fefefe] bg-red-400/40 hover:bg-red-400 transition-all rounded-tr-md hover:rounded-r-none"
        >
          <button className="w-full h-full cursor-pointer" type="submit">
            Log Out
          </button>
        </form>
        <div className="w-full h-18 flex justify-center items-center bg-[#259ed3]/50 rounded-br-md">
          <h2 className="uppercase tracking-wider text-2xl font-semibold text-[#fefefe] ">
            Admin
          </h2>
        </div>
        <div className="w-full">
          <div className="pt-2 bg-blue-100">
            <a
              href="/admin"
              className=" w-full flex h-10 mb-2 justify-center items-center text-xl font-semibold tracking-wide text-[#fefefe] bg-[#259fd3] hover:bg-[#259fd3]/40 transition-all rounded-r-md hover:rounded-r-none"
            >
              Produkte
            </a>
            <a
              href="/admin/add-product"
              className=" w-full flex h-10 mb-2 justify-center items-center text-xl font-semibold tracking-wide text-[#fefefe] bg-[#259fd3] hover:bg-[#259fd3]/40 transition-all rounded-r-md hover:rounded-r-none"
            >
              Add Product
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Nav;
