"use client";

import { useActionState } from "react";
import { loginAction } from "@/lib/login"; // now safe to import

function LoginForm() {
  const [state, action] = useActionState(loginAction);

  return (
    <form action={action}>
      <div className="mb-4">
        <label htmlFor="name" className="block font-semibold">Name:</label>
        <input
          id="name"
          name="name"
          type="text"
          className="bg-[#fefefe] shadow-xl rounded-md focus:outline-0 ps-2 border-b border-black"
          required
        />
      </div>
      <div>
        <label htmlFor="password" className="block font-semibold">Password:</label>
        <input
          id="password"
          name="password"
          type="password"
          className="bg-[#fefefe] shadow-xl rounded-md focus:outline-0 ps-2 border-b border-black"
          required
        />
      </div>
      <div className="mt-3 w-full flex justify-end items-center">
        <button
          className="border px-4 py-1 bg-[#259fd3] text-white font-semibold tracking-wider rounded-md hover:scale-105 cursor-pointer hover:bg-[#259fd3]/80 transition-all"
          type="submit"
        >
          Log in
        </button>
      </div>
      {state?.error && <p className="text-red-600 mt-2">{state.error}</p>}
    </form>
  );
}

export default LoginForm;
