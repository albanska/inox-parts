import Laser from "@/app/components/Laser";

function page() {
  return <Laser />;
}

export default page;
