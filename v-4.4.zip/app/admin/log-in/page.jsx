import { verifySession } from "@/lib/session/session";
import LoginForm from "@/app/components/admin/login/LoginForm.jsx";
import { redirect } from "next/navigation";


async function page() {

  const isLoggedIn = await verifySession()

  if(isLoggedIn) {
     redirect("/admin")
  }

  return (
    <div className="w-full h-screen flex justify-center items-center text-[#4a4e69]">
      <div className="border px-10 py-20 border-black/20 rounded-2xl shadow-md">
        <h2 className="text-center uppercase text-xl font-bold mb-8  tracking-wide">
          Log in
        </h2>
        <LoginForm />
      </div>
    </div>
  );
}

export default page;
