import React from "react";

function page() {
  return <div className="w-full"></div>;
}

export default page;
