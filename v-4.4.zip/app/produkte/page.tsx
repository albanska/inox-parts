import Produkte from "@/app/components/Produkte";

function page() {
  return (
    <Produkte />
  );
}

export default page;
