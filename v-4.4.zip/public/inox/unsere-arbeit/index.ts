import img1 from "./1-1.jpg";
import img2 from "./1-2.jpg";
import img3 from "./1-3.jpg";
import img4 from "./2-1.jpg"
import img5 from "./2-2.jpg"
import img6 from "./2-3.jpg"
import img7 from "./3-1.jpg"
import img8 from "./3-2.jpg"
import img9 from "./3-3.jpg"

export const firstSectImg: any = {
  first: img1 ,
  sec: img2 ,
  third: img3,
};

export const secSectImg: any = {
  first: img4,
  sec: img5,
  third: img6
}

export const thirdSectImg: any = {
  first: img7,
  sec: img8,
  third: img9
}
