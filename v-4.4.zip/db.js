import sqlite3 from "sqlite3";
const db = new sqlite3.Database("data.db");

db.serialize(() => {
  db.run(`
    CREATE TABLE IF NOT EXISTS items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      data TEXT
    )
  `);

  db.run("INSERT INTO items (data) VALUES (?)", [JSON.stringify(arr)]);

  db.run(`
    CREATE TABLE IF NOT EXISTS admin (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT,
      password TEXT
    )
  `);

  db.run("INSERT INTO admin (name, password) VALUES (?, ?)", [
    "Admin",
    "123456",
  ]);
});

db.close();


